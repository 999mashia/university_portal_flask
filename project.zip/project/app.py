from flask import Flask, request, render_template, session, redirect, url_for , g
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import timedelta
import re
from cryptography.fernet import Fernet

app = Flask(__name__)

app.secret_key = 'some_dev_key'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(seconds=20)


#data base object
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect('DB_STU.db')
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(error):
    db = g.pop('db', None)

    if db is not None:
        db.close()


#encryption

ENCRYPTION_KEY = b'kAfil37Az8XskDvrDzIa4XQYc8oC7qU1x7UNNwLjeg8='
cipher = Fernet(ENCRYPTION_KEY)

def encrypt_data(data):
    if data:
        # data.encode() turns string to bytes -> encrypt -> decode back to string for SQLite
        return cipher.encrypt(data.encode()).decode()
    return data

def decrypt_data(data):
    if data:
        try:
            return cipher.decrypt(data.encode()).decode()
        except Exception:
            return "Decryption Error"
    return data







@app.route("/")
def index():

    return render_template('index.html')




@app.route("/register",methods=["GET","POST"])
def register():
    if request.method == "POST":
        user_name = request.form.get("username")
        role = request.form.get("role")
        full_name = request.form.get("full_name")
        university_id = request.form.get("university_id")
        college = request.form.get("college")
        email = request.form.get("email")
        phone = request.form.get("phone")



#encrypting data

        password = request.form.get("password")



        if not is_password_strong(password):
            return "Password is too weak! Must be 8+ chars with upper, lower, number, and symbol."

        e_full_name = encrypt_data(request.form.get("full_name"))


        e_university_id =encrypt_data(request.form.get("university_id"))
        e_college =encrypt_data (request.form.get("college"))
        e_email = encrypt_data(request.form.get("email"))

        e_phone = encrypt_data(request.form.get("phone"))

        hashed_pass = generate_password_hash(password)

        db = get_db()

        try:

            cursor = db.execute(
                "INSERT INTO users (username, password_hash, role, college) VALUES (?, ?, ?, ?)",
                (user_name, hashed_pass, role, college)
            )

            new_user_id = cursor.lastrowid


            db.execute(
            """INSERT INTO students (full_name, university_id, college, email, phone, user_id)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (e_full_name, e_university_id, college, e_email, e_phone, new_user_id)
            )

            db.commit()
            return redirect(url_for('login'))

        except sqlite3.IntegrityError:
            db.rollback()
            return "Check your input"

    return render_template('register.html')





@app.route("/login",methods=["GET","POST"])
def login():



    if request.method == "POST":


        user_name = request.form.get("username")
        password = request.form.get("password")

        db = get_db()

        user = db.execute("SELECT * FROM users WHERE username = ?", (user_name,)).fetchone()

        if user:
            if user['is_locked'] == 1:

                return render_template("login.html", error=" الحساب مغلق لاسباب امنية, تواصل مع قسم it في الجامعه")
            if check_password_hash(user['password_hash'], password):
                db.execute("UPDATE users SET failed_attempts = 0 WHERE user_id = ?", (user['user_id'],))
                db.commit()
                session.permanent= True
                session['user_id'] = user['user_id']
                session['role'] = user['role']
                session['username'] = user['username']
                return redirect(url_for('dashboard'))

            else:

                updated_user = db.execute("SELECT failed_attempts FROM users WHERE user_id = ?", (user['user_id'],)).fetchone()
                new_count = (user['failed_attempts'] or 0) + 1

                if new_count >= 3:
                    # We update both the count and the lock status
                    db.execute("UPDATE users SET failed_attempts = ?, is_locked = 1 WHERE user_id = ?",
                            (new_count, user['user_id']))
                else:
                    db.execute("UPDATE users SET failed_attempts = ? WHERE user_id = ?",
                            (new_count, user['user_id']))
                db.commit()

                return render_template("login.html", error="خطأ في اسم المستخدم أو كلمة المرور")
        else:

            return render_template("login.html", error="خطأ في اسم المستخدم أو كلمة المرور")


    return render_template('login.html')




@app.route("/delete_student/<int:user_id>", methods=["POST"])
def delete_student(user_id):
    if session.get('role') != 'admin':
        return "Unauthorized", 403

    db = get_db()
    db.execute("DELETE FROM students WHERE user_id = ?", (user_id,))
    db.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
    db.commit()
    return redirect(url_for('dashboard'))




@app.route("/dashboard")
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    db = get_db()

    if session['role'] == 'admin':
        rows = db.execute("""
            SELECT u.user_id, s.full_name, s.university_id, s.college, s.phone
            FROM users u
            JOIN students s ON u.user_id = s.user_id
        """).fetchall()

        decrypted_rows = []

        for row in rows:
            r = dict(row)
            r['full_name'] = decrypt_data(row['full_name'])
            r['university_id'] = decrypt_data(row['university_id'])
            r['phone'] = decrypt_data(row['phone'])
            decrypted_rows.append(r)

        return render_template("dashboard.html", rows_T=decrypted_rows)

    else:

        student_data = db.execute("""
            SELECT s.full_name, g.english_grade, g.software_engineering, g.forensics_grade
            FROM students s
            LEFT JOIN grades g ON s.student_id = g.student_id
            WHERE s.user_id = ?
        """, (session['user_id'],)).fetchone()

        s_data = dict(student_data) if student_data else None
        if s_data:
            s_data['full_name'] = decrypt_data(student_data['full_name'])
            s_data['university_id'] = decrypt_data(student_data['university_id'])

        return render_template("dashboard.html", student=s_data)





@app.route("/edit_grades/<int:user_id>", methods=["GET", "POST"])
def edit_grades(user_id):
    if session.get('role') != 'admin':
        return redirect(url_for('login'))

    db = get_db()


    row = db.execute ("SeLECT * FROM  students WHERE user_id = ?", (user_id,)).fetchone()

    if not row:
        return "student not found"

    student = dict(row)
    student['full_name'] = decrypt_data(row['full_name'])

    if request.method == "POST":
        eng = request.form.get("english")
        soft = request.form.get("software")
        foren = request.form.get("forensics")

        existing = db.execute("SELECT grade_id FROM grades WHERE student_id = ?", (student['student_id'],)).fetchone()

        if existing:
            db.execute("UPDATE grades SET english_grade=?, software_engineering=? ,forensics_grade=? Where student_id=?", (eng, soft, foren, student['student_id']))

        else:
            db.execute(" insert into grades (student_id, english_grade, software_engineering, forensics_grade) VALUES (?, ?, ?, ?)", (student['student_id'], eng, soft, foren))


        db.commit()

        return redirect(url_for('dashboard'))

    grades = db.execute("select * From grades where student_id = ?", (student['student_id'], )).fetchone()

    return render_template ("edit_grades.html", student=student, grades=grades)



@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for('login'))




def is_password_strong(password):
    # Min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special char
    if len(password) < 8:
        return False
    if not re.search(r"[a-z]", password) or not re.search(r"[A-Z]", password):
        return False
    if not re.search(r"[0-9]", password) or not re.search(r"[@$!%*?&]", password):
        return False
    return True








